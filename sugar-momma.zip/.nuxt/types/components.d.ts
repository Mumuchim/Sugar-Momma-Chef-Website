
import type { DefineComponent, SlotsType } from 'vue'
type IslandComponent<T> = DefineComponent<{}, {refresh: () => Promise<void>}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, SlotsType<{ fallback: { error: unknown } }>> & T

type HydrationStrategies = {
  hydrateOnVisible?: IntersectionObserverInit | true
  hydrateOnIdle?: number | true
  hydrateOnInteraction?: keyof HTMLElementEventMap | Array<keyof HTMLElementEventMap> | true
  hydrateOnMediaQuery?: string
  hydrateAfter?: number
  hydrateWhen?: boolean
  hydrateNever?: true
}
type LazyComponent<T> = DefineComponent<HydrationStrategies, {}, {}, {}, {}, {}, {}, { hydrated: () => void }> & T

interface _GlobalComponents {
  AdminImageUpload: typeof import("../../components/admin/AdminImageUpload.vue")['default']
  AdminNavLink: typeof import("../../components/admin/AdminNavLink.vue")['default']
  AdminSection: typeof import("../../components/admin/AdminSection.vue")['default']
  AdminStatCard: typeof import("../../components/admin/StatCard.vue")['default']
  LayoutAppFooter: typeof import("../../components/layout/AppFooter.vue")['default']
  LayoutAppHeader: typeof import("../../components/layout/AppHeader.vue")['default']
  RecipeCollectionCard: typeof import("../../components/recipe/CollectionCard.vue")['default']
  RecipeCard: typeof import("../../components/recipe/RecipeCard.vue")['default']
  UiClassBookingModal: typeof import("../../components/ui/ClassBookingModal.vue")['default']
  UiClassCard: typeof import("../../components/ui/ClassCard.vue")['default']
  UiCollectionCardSkeleton: typeof import("../../components/ui/CollectionCardSkeleton.vue")['default']
  UiLoadingSpinner: typeof import("../../components/ui/LoadingSpinner.vue")['default']
  UiNewsletterSignup: typeof import("../../components/ui/NewsletterSignup.vue")['default']
  UiPageHero: typeof import("../../components/ui/PageHero.vue")['default']
  UiRecipeCardSkeleton: typeof import("../../components/ui/RecipeCardSkeleton.vue")['default']
  UiSugarMommaLogo: typeof import("../../components/ui/SugarMommaLogo.vue")['default']
  UiThemeToggle: typeof import("../../components/ui/ThemeToggle.vue")['default']
  UiToastContainer: typeof import("../../components/ui/ToastContainer.vue")['default']
  NuxtWelcome: typeof import("../../node_modules/nuxt/dist/app/components/welcome.vue")['default']
  NuxtLayout: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-layout")['default']
  NuxtErrorBoundary: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']
  ClientOnly: typeof import("../../node_modules/nuxt/dist/app/components/client-only")['default']
  DevOnly: typeof import("../../node_modules/nuxt/dist/app/components/dev-only")['default']
  ServerPlaceholder: typeof import("../../node_modules/nuxt/dist/app/components/server-placeholder")['default']
  NuxtLink: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-link")['default']
  NuxtLoadingIndicator: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']
  NuxtTime: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']
  NuxtRouteAnnouncer: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']
  NuxtImg: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']
  NuxtPicture: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']
  NuxtPage: typeof import("../../node_modules/nuxt/dist/pages/runtime/page")['default']
  NoScript: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['NoScript']
  Link: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Link']
  Base: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Base']
  Title: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Title']
  Meta: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Meta']
  Style: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Style']
  Head: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Head']
  Html: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Html']
  Body: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Body']
  NuxtIsland: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-island")['default']
  LazyAdminImageUpload: LazyComponent<typeof import("../../components/admin/AdminImageUpload.vue")['default']>
  LazyAdminNavLink: LazyComponent<typeof import("../../components/admin/AdminNavLink.vue")['default']>
  LazyAdminSection: LazyComponent<typeof import("../../components/admin/AdminSection.vue")['default']>
  LazyAdminStatCard: LazyComponent<typeof import("../../components/admin/StatCard.vue")['default']>
  LazyLayoutAppFooter: LazyComponent<typeof import("../../components/layout/AppFooter.vue")['default']>
  LazyLayoutAppHeader: LazyComponent<typeof import("../../components/layout/AppHeader.vue")['default']>
  LazyRecipeCollectionCard: LazyComponent<typeof import("../../components/recipe/CollectionCard.vue")['default']>
  LazyRecipeCard: LazyComponent<typeof import("../../components/recipe/RecipeCard.vue")['default']>
  LazyUiClassBookingModal: LazyComponent<typeof import("../../components/ui/ClassBookingModal.vue")['default']>
  LazyUiClassCard: LazyComponent<typeof import("../../components/ui/ClassCard.vue")['default']>
  LazyUiCollectionCardSkeleton: LazyComponent<typeof import("../../components/ui/CollectionCardSkeleton.vue")['default']>
  LazyUiLoadingSpinner: LazyComponent<typeof import("../../components/ui/LoadingSpinner.vue")['default']>
  LazyUiNewsletterSignup: LazyComponent<typeof import("../../components/ui/NewsletterSignup.vue")['default']>
  LazyUiPageHero: LazyComponent<typeof import("../../components/ui/PageHero.vue")['default']>
  LazyUiRecipeCardSkeleton: LazyComponent<typeof import("../../components/ui/RecipeCardSkeleton.vue")['default']>
  LazyUiSugarMommaLogo: LazyComponent<typeof import("../../components/ui/SugarMommaLogo.vue")['default']>
  LazyUiThemeToggle: LazyComponent<typeof import("../../components/ui/ThemeToggle.vue")['default']>
  LazyUiToastContainer: LazyComponent<typeof import("../../components/ui/ToastContainer.vue")['default']>
  LazyNuxtWelcome: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/welcome.vue")['default']>
  LazyNuxtLayout: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-layout")['default']>
  LazyNuxtErrorBoundary: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']>
  LazyClientOnly: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/client-only")['default']>
  LazyDevOnly: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/dev-only")['default']>
  LazyServerPlaceholder: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
  LazyNuxtLink: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-link")['default']>
  LazyNuxtLoadingIndicator: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']>
  LazyNuxtTime: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']>
  LazyNuxtRouteAnnouncer: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']>
  LazyNuxtImg: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']>
  LazyNuxtPicture: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']>
  LazyNuxtPage: LazyComponent<typeof import("../../node_modules/nuxt/dist/pages/runtime/page")['default']>
  LazyNoScript: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['NoScript']>
  LazyLink: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Link']>
  LazyBase: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Base']>
  LazyTitle: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Title']>
  LazyMeta: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Meta']>
  LazyStyle: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Style']>
  LazyHead: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Head']>
  LazyHtml: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Html']>
  LazyBody: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Body']>
  LazyNuxtIsland: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-island")['default']>
}

declare module 'vue' {
  export interface GlobalComponents extends _GlobalComponents { }
}

export {}
