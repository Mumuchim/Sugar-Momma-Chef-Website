declare module '#supabase/server' {
  const serverSupabaseClient: typeof import('D:/FOR APPLYING WORK FILES/PROJECTS/sugar-momma/node_modules/@nuxtjs/supabase/dist/runtime/server/services').serverSupabaseClient
  const serverSupabaseServiceRole: typeof import('D:/FOR APPLYING WORK FILES/PROJECTS/sugar-momma/node_modules/@nuxtjs/supabase/dist/runtime/server/services').serverSupabaseServiceRole
  const serverSupabaseUser: typeof import('D:/FOR APPLYING WORK FILES/PROJECTS/sugar-momma/node_modules/@nuxtjs/supabase/dist/runtime/server/services').serverSupabaseUser
  const serverSupabaseSession: typeof import('D:/FOR APPLYING WORK FILES/PROJECTS/sugar-momma/node_modules/@nuxtjs/supabase/dist/runtime/server/services').serverSupabaseSession
}