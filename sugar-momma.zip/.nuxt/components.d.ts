
import type { DefineComponent, SlotsType } from 'vue'
type IslandComponent<T> = DefineComponent<{}, {refresh: () => Promise<void>}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, SlotsType<{ fallback: { error: unknown } }>> & T

type HydrationStrategies = {
  hydrateOnVisible?: IntersectionObserverInit | true
  hydrateOnIdle?: number | true
  hydrateOnInteraction?: keyof HTMLElementEventMap | Array<keyof HTMLElementEventMap> | true
  hydrateOnMediaQuery?: string
  hydrateAfter?: number
  hydrateWhen?: boolean
  hydrateNever?: true
}
type LazyComponent<T> = DefineComponent<HydrationStrategies, {}, {}, {}, {}, {}, {}, { hydrated: () => void }> & T


export const AdminImageUpload: typeof import("../components/admin/AdminImageUpload.vue")['default']
export const AdminNavLink: typeof import("../components/admin/AdminNavLink.vue")['default']
export const AdminSection: typeof import("../components/admin/AdminSection.vue")['default']
export const AdminStatCard: typeof import("../components/admin/StatCard.vue")['default']
export const LayoutAppFooter: typeof import("../components/layout/AppFooter.vue")['default']
export const LayoutAppHeader: typeof import("../components/layout/AppHeader.vue")['default']
export const RecipeCollectionCard: typeof import("../components/recipe/CollectionCard.vue")['default']
export const RecipeCard: typeof import("../components/recipe/RecipeCard.vue")['default']
export const UiClassBookingModal: typeof import("../components/ui/ClassBookingModal.vue")['default']
export const UiClassCard: typeof import("../components/ui/ClassCard.vue")['default']
export const UiCollectionCardSkeleton: typeof import("../components/ui/CollectionCardSkeleton.vue")['default']
export const UiLoadingSpinner: typeof import("../components/ui/LoadingSpinner.vue")['default']
export const UiNewsletterSignup: typeof import("../components/ui/NewsletterSignup.vue")['default']
export const UiPageHero: typeof import("../components/ui/PageHero.vue")['default']
export const UiRecipeCardSkeleton: typeof import("../components/ui/RecipeCardSkeleton.vue")['default']
export const UiSugarMommaLogo: typeof import("../components/ui/SugarMommaLogo.vue")['default']
export const UiThemeToggle: typeof import("../components/ui/ThemeToggle.vue")['default']
export const UiToastContainer: typeof import("../components/ui/ToastContainer.vue")['default']
export const NuxtWelcome: typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']
export const NuxtLayout: typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']
export const NuxtErrorBoundary: typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']
export const ClientOnly: typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']
export const DevOnly: typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']
export const ServerPlaceholder: typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']
export const NuxtLink: typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']
export const NuxtLoadingIndicator: typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']
export const NuxtTime: typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']
export const NuxtRouteAnnouncer: typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']
export const NuxtImg: typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']
export const NuxtPicture: typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']
export const NuxtPage: typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']
export const NoScript: typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']
export const Link: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']
export const Base: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']
export const Title: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']
export const Meta: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']
export const Style: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']
export const Head: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']
export const Html: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']
export const Body: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']
export const NuxtIsland: typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']
export const LazyAdminImageUpload: LazyComponent<typeof import("../components/admin/AdminImageUpload.vue")['default']>
export const LazyAdminNavLink: LazyComponent<typeof import("../components/admin/AdminNavLink.vue")['default']>
export const LazyAdminSection: LazyComponent<typeof import("../components/admin/AdminSection.vue")['default']>
export const LazyAdminStatCard: LazyComponent<typeof import("../components/admin/StatCard.vue")['default']>
export const LazyLayoutAppFooter: LazyComponent<typeof import("../components/layout/AppFooter.vue")['default']>
export const LazyLayoutAppHeader: LazyComponent<typeof import("../components/layout/AppHeader.vue")['default']>
export const LazyRecipeCollectionCard: LazyComponent<typeof import("../components/recipe/CollectionCard.vue")['default']>
export const LazyRecipeCard: LazyComponent<typeof import("../components/recipe/RecipeCard.vue")['default']>
export const LazyUiClassBookingModal: LazyComponent<typeof import("../components/ui/ClassBookingModal.vue")['default']>
export const LazyUiClassCard: LazyComponent<typeof import("../components/ui/ClassCard.vue")['default']>
export const LazyUiCollectionCardSkeleton: LazyComponent<typeof import("../components/ui/CollectionCardSkeleton.vue")['default']>
export const LazyUiLoadingSpinner: LazyComponent<typeof import("../components/ui/LoadingSpinner.vue")['default']>
export const LazyUiNewsletterSignup: LazyComponent<typeof import("../components/ui/NewsletterSignup.vue")['default']>
export const LazyUiPageHero: LazyComponent<typeof import("../components/ui/PageHero.vue")['default']>
export const LazyUiRecipeCardSkeleton: LazyComponent<typeof import("../components/ui/RecipeCardSkeleton.vue")['default']>
export const LazyUiSugarMommaLogo: LazyComponent<typeof import("../components/ui/SugarMommaLogo.vue")['default']>
export const LazyUiThemeToggle: LazyComponent<typeof import("../components/ui/ThemeToggle.vue")['default']>
export const LazyUiToastContainer: LazyComponent<typeof import("../components/ui/ToastContainer.vue")['default']>
export const LazyNuxtWelcome: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']>
export const LazyNuxtLayout: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']>
export const LazyNuxtErrorBoundary: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']>
export const LazyClientOnly: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']>
export const LazyDevOnly: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']>
export const LazyServerPlaceholder: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
export const LazyNuxtLink: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']>
export const LazyNuxtLoadingIndicator: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']>
export const LazyNuxtTime: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']>
export const LazyNuxtRouteAnnouncer: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']>
export const LazyNuxtImg: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']>
export const LazyNuxtPicture: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']>
export const LazyNuxtPage: LazyComponent<typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']>
export const LazyNoScript: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']>
export const LazyLink: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']>
export const LazyBase: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']>
export const LazyTitle: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']>
export const LazyMeta: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']>
export const LazyStyle: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']>
export const LazyHead: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']>
export const LazyHtml: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']>
export const LazyBody: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']>
export const LazyNuxtIsland: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']>

export const componentNames: string[]
